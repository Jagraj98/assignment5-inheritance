﻿// Jagraj Singh , C0904213
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment5_Inheritance
    {
        //Super class
        abstract class Mail
        {
            public double Weight { get; set; }
            public bool IsExpress { get; set; }
            public string Destination { get; set; }

            public Mail(double weight, bool express, string destination){
                Weight = weight;
                IsExpress = express;
                Destination = destination;
            }
            public abstract double Stamp();
            public bool IsValid(){
                return !string.IsNullOrEmpty(Destination);
            }
        }
        class Letter : Mail
        {
            public string Format { get; set; }
            public Letter(double weight, bool isExpress, string destination, string format) : base(weight, isExpress, destination)
            {
                Format = format;}
            public override double Stamp()
            {
                double amount;
                if (IsValid())
                {
                    if (IsExpress)
                    {
                        amount = 2 * (Format == "A4" ? 3.50 : 2.50) + 2 * Weight / 1000.0;}
                    else
                    {
                        amount = (Format == "A4" ? 3.50 : 2.50) + Weight / 1000.0;}
                }
                else
                {
                    amount = 0;
                }
                return amount;
            }
        }
        class Parcel : Mail
        {
            public double Volume { get; set; }
            public Parcel(double weight, bool isExpress, string destination, double volume) : base(weight, isExpress, destination)
            {
                Volume = volume;
            }
            public override double Stamp()
            {
                double amount;
                if (IsValid())
                {
                    if (IsExpress)
                    {
                        amount = 2 * (0.25 * Volume + Weight / 1000.0);
                    }
                    else
                    {
                        amount = 0.25 * Volume + Weight / 1000.0;
                    }
                }
                else
                {
                    amount = 0;
                }
                return amount;
            }
        }
        class Advertisement : Mail
        {
                public Advertisement(double weight, bool isExpress, string destination) : base(weight, isExpress, destination)

        { }
            public override double Stamp()
            {
                double amount;
                if (IsValid())
                {
                    if (IsExpress)
                    {
                        amount = 2 * 5 * Weight / 1000.0;
                    }
                    else
                    {
                        amount = 5 * Weight / 1000.0;
                    }
                }
                else
                {
                    amount = 0;
                }
                return amount;
            }
        }
        class Mailbox
        {
            private List<Mail> mails;
            public Mailbox()
            {
                mails = new List<Mail>();
            }
            public void AddMail(Mail mail)
            {
                mails.Add(mail);
            }
            public double Stamp()
            {
                double totalPostage = 0;
                foreach (Mail mail in mails)
                {
                    totalPostage += mail.Stamp();
                }
                return totalPostage;
            }
            public int InvalidMails()
            {
                int invalidCount = 0;
                foreach (Mail mail in mails)
                {
                    if (!mail.IsValid())
                    {
                        invalidCount++;
                    }
                }
                return invalidCount;
            }
            public void Display()
            {
                foreach (Mail mail in mails)
                {
                    if (mail.IsValid())
                    {
                        Console.WriteLine(mail.GetType().Name);
                        Console.WriteLine("Weight: " + mail.Weight + " grams");
                        Console.WriteLine("Express: " + (mail.IsExpress ? "yes" : "no"));
                        Console.WriteLine("Destination: " + mail.Destination);
                        Console.WriteLine("Price: $" + mail.Stamp());
                        if (mail is Letter)
                        {
                            Console.WriteLine("Format: " + ((Letter)mail).Format);
                        }
                        else if (mail is Parcel)
                        {
                            Console.WriteLine("Volume: " + ((Parcel)mail).Volume + " liters");
                        }
                    }
                    else
                    {
                        Console.WriteLine(mail.GetType().Name);
                        Console.WriteLine("(Invalid courier)");
                        Console.WriteLine("Weight: " + mail.Weight + " grams");
                        Console.WriteLine("Express: " + (mail.IsExpress ? "yes" : "no"));
                        Console.WriteLine("Destination: " + mail.Destination);
                        Console.WriteLine("Price: $0.0");
                    }
                    Console.WriteLine();
                }
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                Mailbox mailbox = new Mailbox();

                mailbox.AddMail(new Letter(200.0, true, "Chemin des Acacias 28, 1009 Pully", "A3"));
                mailbox.AddMail(new Letter(800.0, false, "", "A4"));
                mailbox.AddMail(new Advertisement(1500.0, true, "Les Moilles 13A, 1913 Saillon"));
                mailbox.AddMail(new Advertisement(3000.0, false, ""));
                mailbox.AddMail(new Parcel(5000.0, true, "Grand rue 18, 1950 Sion", 30.0));
                mailbox.AddMail(new Parcel(3000.0, true, "Chemin des fleurs 48, 2800 Delemont", 0.0));
                mailbox.Display();
                Console.WriteLine("The total amount of postage is " + mailbox.Stamp());
            }
        }
    }

